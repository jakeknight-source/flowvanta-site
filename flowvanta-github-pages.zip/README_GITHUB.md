# Flowvanta — GitHub Pages Ready

This folder is tailored for **GitHub Pages**. It includes a Formspree-based contact form and Calendly popup.

## Deploy on GitHub Pages
1. Create a new repository on GitHub (e.g. `flowvanta-site`).
2. Upload **all files in this folder** to the repo root and commit.
3. Go to **Settings → Pages → Build and deployment**:
   - Source: **Deploy from a branch**
   - Branch: **main** / root (**/**)
4. Wait ~30–60 seconds. Your site will be live at:
   - `https://YOUR-USERNAME.github.io/flowvanta-site/` (or the root if using a user/organization repo).

## Contact Form (Formspree)
- Replace the placeholder endpoint in `index.html`:
  ```html
  <form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
  ```
- Get your endpoint by signing up at https://formspree.io/ and creating a new form.
- The form redirects to `/thank-you.html` after submission.

## Custom Domain (optional)
1. In your DNS provider, create a CNAME record pointing your domain to:
   - `YOUR-USERNAME.github.io`
2. Create a file named **CNAME** in the repo root with just your domain:
   ```
   yourdomain.com
   ```
3. In **Settings → Pages**, set your custom domain and enforce HTTPS.

## Calendly
- Calendly link is already wired into every CTA (popup enabled).
- You can change it in the `<body>` attribute inside `index.html`:
  ```html
  <body data-calendly="https://calendly.com/jakeknight-getflowvanta/ai-automation-strategy-call">
  ```

## SEO
- Update `sitemap.xml` and Open Graph meta tags in `index.html` with your domain if you use a custom domain.
- `robots.txt` is included by default.

## Tip
If you prefer, you can still **connect this GitHub repo to Netlify or Vercel** later for instant CI/CD deployments and advanced features.
